const request = require('request'); 
var geocodeAddress =(address,callback) => {
var encodeAddress = encodeURIComponent(address); 
request ({
url:`https://maps.googleapis.com/maps/api/geocode/json?address=${encodeAddress}`,
//url: 'http://api.openweathermap.org/geo/1.0/direct?q=London&limit=5&appid={66cd1e6fea07f0f569ae13b5ab5bddf3}',
  
json:true 
},(error,response,body)=> {
if(error) 
{
callback('Unable to conncet google Servers');
}
else if(body.status === 'ZERO_RESULTS')
{
callback('Unable to find address');
}
else if(body.status === 'OK')
{
callback(undefined,{ 
address: body.results[0].formatted_address, 
latitude: body.results[0].geometry.location.lat, 
longitude: body.results[0].geometry.location.lng 
});
} 
}); 
} 
module.exports.getAddress = geocodeAddress;

