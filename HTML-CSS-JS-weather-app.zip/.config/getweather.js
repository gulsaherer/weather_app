////weather api call
// https://api.openweathermap.org/data/2.5/weather?q=London&appid

npm init -y && npm i --save-dev node@16 && npm config set prefix=$(pwd)/node
//npm init 

const request =require('request');

var getWeather = (lat,lon,callback) => {
    request ({
       url: `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid={66cd1e6fea07f0f569ae13b5ab5bddf3}`,
      //url: 'http://api.openweathermap.org/geo/1.0/reverse?lat=51.5098&lon=-0.1180&limit=5&appid={66cd1e6fea07f0f569ae13b5ab5bddf3}',
        json: true
    },(error,response,body)=>
    {
        if(!error && response.statusCode === 200)
        {
           // console.log(body.main.temp)
           callback(undefined,{
            Temp: body.main.temp
           });
        }
        else {
            //console.log('unable to fetch weather');
            callback('unable to fetch weather');
        }

    });
};

module.exports.getWeather = getWeather;
////